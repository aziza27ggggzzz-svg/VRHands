package com.example.vrhands;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.View;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().getDecorView().setSystemUiVisibility(5894 | 512 | 1024 | 4096);
    WebView w = new WebView(this);
    w.setBackgroundColor(0xff101522);
    WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(false);
    setContentView(w); w.loadUrl("file:///android_asset/index.html");
  }
}
