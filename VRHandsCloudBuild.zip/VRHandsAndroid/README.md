# VR Hands Android starter

A fullscreen Android app wrapper around the prototype, with a home-screen launcher icon/app entry. The game is still a prototype: finger tracking is not implemented; touch controls and device orientation are used. Three.js is loaded from a CDN, so internet is currently required.

## Build APK
1. Open this folder in Android Studio (Open project).
2. Allow Gradle sync; install Android SDK 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer/install it on your Android phone. Android may ask to allow installation from that source.

This source project is not itself an APK. It needs Android Studio/Android SDK to compile.
